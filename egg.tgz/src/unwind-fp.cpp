// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Walk frame pointers"); }
int main(){
  announce();
  return lionss_run_workload("unwind-fp");
}
