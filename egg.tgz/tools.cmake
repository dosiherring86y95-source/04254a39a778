# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(windward src/windward.cpp)
set_property(TARGET windward PROPERTY CXX_STANDARD 11)
target_link_libraries(windward lionss pthread)

add_executable(stm8_eeprom src/stm8_eeprom.cpp)
set_property(TARGET stm8_eeprom PROPERTY CXX_STANDARD 11)
target_link_libraries(stm8_eeprom lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(jitProfile src/jitProfile.cpp)
set_property(TARGET jitProfile PROPERTY CXX_STANDARD 11)
target_link_libraries(jitProfile lionss pthread)

add_executable(gmres_restart src/gmres_restart.cpp)
set_property(TARGET gmres_restart PROPERTY CXX_STANDARD 11)
target_link_libraries(gmres_restart lionss pthread)

add_executable(Wrenfield src/Wrenfield.cpp)
set_property(TARGET Wrenfield PROPERTY CXX_STANDARD 11)
target_link_libraries(Wrenfield lionss pthread)

add_executable(flintlock src/flintlock.cpp)
set_property(TARGET flintlock PROPERTY CXX_STANDARD 11)
target_link_libraries(flintlock lionss pthread)

add_executable(lut-grade src/lut-grade.cpp)
set_property(TARGET lut-grade PROPERTY CXX_STANDARD 11)
target_link_libraries(lut-grade lionss pthread)

add_executable(walReplay src/walReplay.cpp)
set_property(TARGET walReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(walReplay lionss pthread)

add_executable(aftermathDump src/aftermathDump.cpp)
set_property(TARGET aftermathDump PROPERTY CXX_STANDARD 11)
target_link_libraries(aftermathDump lionss pthread)

add_executable(openapi_lint src/openapi_lint.cpp)
set_property(TARGET openapi_lint PROPERTY CXX_STANDARD 11)
target_link_libraries(openapi_lint lionss pthread)

add_executable(unwind-fp src/unwind-fp.cpp)
set_property(TARGET unwind-fp PROPERTY CXX_STANDARD 11)
target_link_libraries(unwind-fp lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(beamSearch4 src/beamSearch4.cpp)
set_property(TARGET beamSearch4 PROPERTY CXX_STANDARD 11)
target_link_libraries(beamSearch4 lionss pthread)

add_executable(apparmor_profile src/apparmor_profile.cpp)
set_property(TARGET apparmor_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(apparmor_profile lionss pthread)

add_executable(NavMeshBake src/NavMeshBake.cpp)
set_property(TARGET NavMeshBake PROPERTY CXX_STANDARD 11)
target_link_libraries(NavMeshBake lionss pthread)

add_executable(helmLint src/helmLint.cpp)
set_property(TARGET helmLint PROPERTY CXX_STANDARD 11)
target_link_libraries(helmLint lionss pthread)

add_executable(kalman-unscented src/kalman-unscented.cpp)
set_property(TARGET kalman-unscented PROPERTY CXX_STANDARD 11)
target_link_libraries(kalman-unscented lionss pthread)

add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(LorawanAdr src/LorawanAdr.cpp)
set_property(TARGET LorawanAdr PROPERTY CXX_STANDARD 11)
target_link_libraries(LorawanAdr lionss pthread)

add_executable(vermilion src/vermilion.cpp)
set_property(TARGET vermilion PROPERTY CXX_STANDARD 11)
target_link_libraries(vermilion lionss pthread)

add_executable(coral-9 src/coral-9.cpp)
set_property(TARGET coral-9 PROPERTY CXX_STANDARD 11)
target_link_libraries(coral-9 lionss pthread)

add_executable(predicate_pushdown src/predicate_pushdown.cpp)
set_property(TARGET predicate_pushdown PROPERTY CXX_STANDARD 11)
target_link_libraries(predicate_pushdown lionss pthread)

add_executable(sam_sort src/sam_sort.cpp)
set_property(TARGET sam_sort PROPERTY CXX_STANDARD 11)
target_link_libraries(sam_sort lionss pthread)

add_executable(orbit-propagate src/orbit-propagate.cpp)
set_property(TARGET orbit-propagate PROPERTY CXX_STANDARD 11)
target_link_libraries(orbit-propagate lionss pthread)

add_executable(GiProbeBake src/GiProbeBake.cpp)
set_property(TARGET GiProbeBake PROPERTY CXX_STANDARD 11)
target_link_libraries(GiProbeBake lionss pthread)

add_executable(stereoDepth src/stereoDepth.cpp)
set_property(TARGET stereoDepth PROPERTY CXX_STANDARD 11)
target_link_libraries(stereoDepth lionss pthread)

add_executable(cobalt-run src/cobalt-run.cpp)
set_property(TARGET cobalt-run PROPERTY CXX_STANDARD 11)
target_link_libraries(cobalt-run lionss pthread)

add_executable(pgo-merge src/pgo-merge.cpp)
set_property(TARGET pgo-merge PROPERTY CXX_STANDARD 11)
target_link_libraries(pgo-merge lionss pthread)

add_executable(cordite src/cordite.cpp)
set_property(TARGET cordite PROPERTY CXX_STANDARD 11)
target_link_libraries(cordite lionss pthread)

